<출처>
1. Cane, Cannon, Cannonball , PyThony, tornado (CC0)
친구가 그려줬습니다!

1. [sprite/Cannonball (CC0)](https://blog.naver.com/sue9191/220990657338)

1. [enemy/enemy1/슬라임 (CC0)](https://blog.naver.com/sue9191/220997070254)

1. [enemy/enemy2/좀비 (CC0)](https://opengameart.org/content/the-zombie-free-sprites)
(이외의 CC0 licence들은 생략하겠습니다)

1. [enemy/enemy3/마법사 (OGA-BY 3.0)](https://opengameart.org/content/the-zombie-free-sprites)

1. [enemy/enemy4,5/드래곤 (CC-BY 3.0)](https://opengameart.org/content/flying-dragon-rework)

1. [enemy/Boss/explosion (폭발 이펙트) (CC-BY 3.0)](https://opengameart.org/content/explosions-0)

1. [bg/ BG 배경  (CC-BY 3.0, OGA-BY 3.0)](https://opengameart.org/content/tower-defense-prototyping-assets-4-monsters-some-tiles-a-background-image)

1. [skill/Bow1, Cannon (CC-BY 3.0, CC-BY-SA 3.0, GPL 2.0)](https://opengameart.org/content/painterly-spell-icons-part-2)

1. [skill/Bow2, skill/shop/castle_repair, skill/shop/아래 그림들의 모든 frames (CC-BY 3.0, CC-BY-SA 3.0, GPL 2.0, GPL 3.0)](https://opengameart.org/content/painterly-spell-icons-part-3)

1. [skill/Fire (CC-BY 3.0, CC-BY-SA 3.0, GPL 2.0, GPL 3.0)](https://opengameart.org/content/painterly-spell-icons-part-4)

1. [bg/gameclear_BG의 하늘 (GPL 2.0)](https://opengameart.org/content/pixelantasy)

1. [bg/gameclear_BG 의 꽃들 (CC-BY 4.0)](https://opengameart.org/content/plants-and-flowers-pixel-art)

1. [font/maplestory Bold, Light (아래에 설명)](https://maplestory.nexon.com/Media/Font)  

```메이플스토리 서체의 지적 재산권을 포함한 모든 권리는 ㈜넥슨코리아에 있습니다.메이플스토리 서체는 개인 및 기업 사용자를 포함한 모든 사용자에게 무료로 제공되며 자유롭게 사용 및 배포하실 수 있습니다. 단, 임의로 수정, 편집 등을 할 수 없으며 배포되는 형태 그대로 사용해야 합니다.글꼴 자체를 유료로 판매하는 것은 금지되며, 메이플스토리 서체의 본 저작권 안내를 포함해서 다른 소프트웨어와 번들하거나 임베디드 폰트로 사용하실 수 있습니다.메이플스토리 서체의 출처 표기를 권장합니다. 예) 이 페이지에는 메이플스토리가 제공한 메이플스토리 서체가 적용되어 있습니다.메이플스토리 서체를 사용한 인쇄물, 광고물(온라인 포함)은 넥슨의 프로모션을 위해 활용될 수 있습니다. 이를 원치 않는 사용자는 언제든지 넥슨에 요청하실 수 있습니다.```

파생물들은 모두 원본의 라이선스를 따릅니다.
